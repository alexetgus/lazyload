[size=16pt][b]Lazyload[/b][/size]

Lazyloading for images displayed in SMF messages.



[size=14pt][b]Description:[/b][/size]

This modification (for SMF 2.0 Final only) adds a feature allowing posts images to be loaded only when they are needed.
If an image is not in the display window, it is not loaded.
The display of a page thus becomes faster.

[b]This feature is essential for mobile phones that are charged by the amount of data they consume.
[/b]


For more information on the JavaScript used, please visit the project's Github repository :
[b][url]https://github.com/aFarkas/lazysizes[/url][/b]


[b][url=https://chez-oim.org]https://chez-oim.org[/url]  -  [i]This mod is copylefted[/i][/b]
To contribute : [b][url=https://github.com/alexetgus/lazyload]https://github.com/alexetgus/lazyload[/url][/b]
